$(document).ready(function(){
    const configurationData = [
        {
            "image":"./images/test-head-img.jpg",
            "text":"这是第一个文本",
        },
        {
            "image":"./images/test-head-img-2.jpg",
            "text":"这是第二个文本",
            "forward-button-text":"修改了第一个按钮的文本",
            "next-button-text":"点击跳转到另一个界面",
            "action":function(obj){
                window.location.href = "./example-site.html";
            }
        },
        {
            "image":"./images/test-head-img-3.jpg",
            "text":"这是第3个文本",
            "forward-button-text":"修改回上一个",
            "next-button-text":"修改回下一个",
        },
        {
            "image":"./images/test-head-img.jpg",
            "text":"这是第4个文本",
            "non-button":true
        },
    ]
    $("#button-forward").click(function(){//上一个 按钮的点击事件
        forward();
        localStorage.currentIndex = currentIndex;
    })
    $("#button-next").click(function(){//下一个 按钮的点击事件
        next();
        localStorage.currentIndex = currentIndex;
    })
    const IMAGE_ID = "image";
    const TEXT_ID = "text"
    const FORWARD_BUTTON_ID = "button-forward";
    const NEXT_BUTTON_ID = "button-next";

    let currentIndex = localStorage.currentIndex?Number(localStorage.currentIndex):0;//当前处在第几个页面
    analyseData(currentIndex);

    function analyseData(index){
        let each_configuration = configurationData[index];
        if(each_configuration.image){//要是有设置图片属性
            $(`#${IMAGE_ID}`).attr("src",each_configuration.image);
        }
        if(each_configuration.text){
            $(`#${TEXT_ID}`).text(each_configuration.text);
        }
        if(each_configuration["forward-button-text"]){//如果设置了 上一个 按钮的文本
            $(`#${FORWARD_BUTTON_ID}`).text(each_configuration["forward-button-text"]);
        }else{
            $(`#${FORWARD_BUTTON_ID}`).text("上一个");
        }
        if(each_configuration["next-button-text"]){//如果设置了 下一个 按钮的文本
            $(`#${NEXT_BUTTON_ID}`).text(each_configuration["next-button-text"]);
        }else{
            $(`#${NEXT_BUTTON_ID}`).text("下一个");
        }
        // if(each_configuration["non-button"]){
        //     $(`#${FORWARD_BUTTON_ID}`).hide();
        //     $(`#${NEXT_BUTTON_ID}`).hide();
        // }else{
        //     $(`#${FORWARD_BUTTON_ID}`).show();
        //     $(`#${NEXT_BUTTON_ID}`).show();
        // }
    }

    function next(){
        if(configurationData[currentIndex]["action"]){
            configurationData[currentIndex].action();
            return;
        }
        if(currentIndex==configurationData.length-1){
            return;
        }
        currentIndex++;
        analyseData(currentIndex);
    }

    function forward(){
        if(currentIndex==0){
            return;
        }
        currentIndex--;
        analyseData(currentIndex);
    }
});